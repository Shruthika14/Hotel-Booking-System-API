﻿namespace Hotel_Booking_System.Auth
{
    public class Response
    {
        public string? Status { get; set; }
        public string? Error { get; set; }
    }
}