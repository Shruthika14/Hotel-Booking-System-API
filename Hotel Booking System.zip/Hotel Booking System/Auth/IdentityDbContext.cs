﻿namespace Hotel_Booking_System.Auth
{
    public class IdentityDbContext<T>
    {
    }
}